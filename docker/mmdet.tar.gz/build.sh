docker build . --tag=docker.4pd.io/hypc-cv-mmdetection:2.15.1-20210824
