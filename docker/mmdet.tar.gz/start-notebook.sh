#!/bin/bash
jupyter-lab --ServerApp.token=123456789 --allow-root --ServerApp.ip=0.0.0.0 --no-browser
